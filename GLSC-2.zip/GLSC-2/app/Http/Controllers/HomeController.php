<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(){
        $posting = [
            [
            "title" => "Mahasiswa Satu",
            "slug" => "mahasiswa satu",
            ],
            [
            "title" => "Mahassiswa Dua",
            "slug" => "mahasiswa dua",
            ]
        ];

        return view('mahasiswa', [
            'menu' => "mahasiswa",
            "mahasiswa" => $posting
        ]);
    }
}
