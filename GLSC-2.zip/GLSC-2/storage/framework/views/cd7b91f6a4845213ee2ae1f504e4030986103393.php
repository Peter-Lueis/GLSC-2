<?php $__env->startSection('title', 'About'); ?>

<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="row">
            <div class="col-10">
                <h1 class="mt-3">Hello, Peter!</h1>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\semester 5\Web Prog\GLSC-2\resources\views/about.blade.php ENDPATH**/ ?>